package com.example.progect1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class BActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_b);
        Button ob= findViewById(R.id.btoc);
        ob.setOnClickListener(view -> {
            Intent intent = new Intent(this, BActivity.class);
            startActivity(intent);
        });
    }
}