package com.example.progect1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class CActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_c);
        Button ob= findViewById(R.id.cc);
        ob.setOnClickListener(view -> {
            Intent intent = new Intent(this, BActivity.class);
            startActivity(intent);
        });
        Button ob1= findViewById(R.id.ctoa);
        ob.setOnClickListener(view -> {
            Intent intent = new Intent(this, BActivity.class);
            startActivity(intent);
        });
        Button ob2= findViewById(R.id.ctod);
        ob.setOnClickListener(view -> {
            Intent intent = new Intent(this, BActivity.class);
            finishAffinity();
            startActivity(intent);
        });
        Button ob3= findViewById(R.id.cs);
        ob.setOnClickListener(view -> {
            finishAffinity();
        });
    }
}