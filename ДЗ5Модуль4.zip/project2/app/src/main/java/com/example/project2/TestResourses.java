package com.example.project2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

import java.util.Random;

public class TestResourses extends AppCompatActivity {
    private boolean isSub = false;
    private View mainLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_resourses);
        Button btSub = findViewById(R.id.sub1);
        String profileName = "@vituh";
        setTitle("Профиль пользоватя"+profileName);
        mainLayout =findViewById(R.id.bac);
        btSub.setOnClickListener(view -> {
            if(isSub){
                Snackbar snackbar = Snackbar.make(view,"Вы точно хтите отписаться от "+profileName+" ?",Snackbar.LENGTH_SHORT);
                snackbar.setAction( "Да",view1 ->{
                    btSub.setText("Подписаться");
                    btSub.setBackgroundColor(getResources().getColor(R.color.unsub));
                    isSub=false;
                });
                snackbar.show();

            } else {
                Toast toast = Toast.makeText(getApplicationContext(),"Вы подписаны на"+profileName,Toast.LENGTH_SHORT);
                btSub.setText("Подписаться");
                btSub.setBackgroundColor(getResources().getColor(R.color.sub));
                toast.show();
                isSub = true;
            }
        });
        Button btC = findViewById(R.id.colorChange);
        btC.setOnClickListener(view -> {
            changeCollar();
        });

    }
    private void changeCollar(){
        Random random = new Random();
        int color = android.graphics.Color.rgb(random.nextInt(256),random.nextInt(256),random.nextInt(256));
        mainLayout.setBackgroundColor(color);
    }
}