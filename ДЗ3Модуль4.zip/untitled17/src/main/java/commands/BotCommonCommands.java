package commands;

public class BotCommonCommands {
    @AppBotCommand(name = "/hello", description = "when request hello", showInkeyBoard = true)
    String hello() {
        return "Hello, User";
    }

    @AppBotCommand(name = "/bye", description = "when request bye", showInkeyBoard = true)
    String bye() {
        return "Good bye, User";
    }

    @AppBotCommand(name = "/help", description = "when request help", showInkeyBoard = true)
    String help() {
        return  "HELP me";
    }
}
