package functions;

import java.lang.reflect.InvocationTargetException;

public interface ImagesOperation {
    float[] execute(float[] rgb) throws InvocationTargetException, IllegalAccessError, IllegalAccessException;
}
