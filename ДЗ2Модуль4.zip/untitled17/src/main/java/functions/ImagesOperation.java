package functions;

public interface ImagesOperation {
    float[] execute(float[] rgb);
}
